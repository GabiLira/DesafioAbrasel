document.addEventListener('DOMContentLoaded', function() {
  const tipoVeiculo = document.getElementById('tipoVeiculo');
  const quantidadeInput = document.getElementById('quantidadeInput');
  const errorMessage = document.getElementById("error-message");

  tipoVeiculo.addEventListener('change', function() {
    if (tipoVeiculo.value.toLowerCase() === 'moto') {
      quantidadeInput.setAttribute('placeholder', 'Quantidade de passageiros');
      quantidadeInput.setAttribute('min', '1');
      quantidadeInput.setAttribute('max', '2');
    } else {
      quantidadeInput.setAttribute('placeholder', 'Quantidade de portas');
      quantidadeInput.removeAttribute('min');
      quantidadeInput.removeAttribute('max');
    }
  });

  const menuButton = document.getElementById('menu');

  menuButton.addEventListener('click', () => {
    window.location.href = 'https://desafioabraselmain.gabi2255.repl.co/';
  });

  function displayMessage(message, isError = true) {
    errorMessage.textContent = message;
    if (!isError) {
      errorMessage.style.color = "green";
    } else {
      errorMessage.style.color = "red";
    }
  }

  document.getElementById("registrarVeiculo").addEventListener("click", function(e) {
    e.preventDefault();

    const tipoVeiculoValue = document.getElementById("tipoVeiculo").value;
    const quantidade = parseInt(document.getElementById("quantidadeInput").value);
    const modelo = document.getElementById("modelo").value;
    const anoFabricacao = document.getElementById("anoFabricacao").value;
    const marca = document.getElementById("marca").value;

    let veiculo;

    try {
      if (
        tipoVeiculoValue === "" ||
        quantidade === "" ||
        modelo === "" ||
        anoFabricacao === "" ||
        marca === ""
      ) {
        throw new Error("Preencha todos os campos para cadastrar o veículo.");
      }

      if (anoFabricacao.length !== 4 || isNaN(parseInt(anoFabricacao))) {
        throw new Error("O ano de fabricação deve conter exatamente 4 dígitos.");
      }

      if (tipoVeiculoValue === "Carro") {
        if (quantidade < 2 || quantidade > 4 || isNaN(quantidade)) {
          throw new Error("A quantidade de portas do carro deve estar entre 2 e 4.");
        }
        veiculo = {
          tipoVeiculo: tipoVeiculoValue,
          modelo: modelo,
          anoFabricacao: anoFabricacao,
          quantidadePortas: quantidade,
          marca: marca
        };
      } else if (tipoVeiculoValue === "Moto") {
        if (quantidade < 1 || quantidade > 2 || isNaN(quantidade)) {
          throw new Error("A quantidade de passageiros da moto deve ser entre 1 e 2.");
        }
        veiculo = {
          tipoVeiculo: tipoVeiculoValue,
          modelo: modelo,
          anoFabricacao: anoFabricacao,
          quantidadePassageiros: quantidade,
          marca: marca,
          quantidadeRodas: 2
        };
      }

      let veiculos = JSON.parse(localStorage.getItem("veiculos")) || [];
      veiculos.push(veiculo);
      localStorage.setItem("veiculos", JSON.stringify(veiculos));

      // Convertendo a lista de veículos em um arquivo JSON
      const jsonData = JSON.stringify(veiculos, null, 2); 
      const blob = new Blob([jsonData], { type: "application/json" });

      // Criando um link para fazer o download do arquivo JSON
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "veiculos.json"; 
      link.click();

      // imprimindo mensages de sucesso e erro
      console.log("Veículo cadastrado com sucesso:", veiculo);
      displayMessage("Veículo cadastrado com sucesso.", false);
    } catch (error) {
      console.error("Erro ao cadastrar veículo:", error.message);
      displayMessage(error.message);
    }
  });
});