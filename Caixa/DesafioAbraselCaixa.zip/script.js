document.addEventListener('DOMContentLoaded', function() {
  const menuButton = document.getElementById('menu');
  const calcularButton = document.getElementById('calcularButton');
  const valorCompraInput = document.getElementById('valorCompra');
  const valorPagoInput = document.getElementById('valorPago');

  menuButton.addEventListener('click', () => {
    window.location.href = 'https://desafioabraselmain.gabi2255.repl.co/';
  });

  calcularButton.addEventListener('click', (event) => {
    event.preventDefault();

    const valorCompra = parseInt(valorCompraInput.value);
    const valorPago = parseInt(valorPagoInput.value);

    if (isNaN(valorCompra) || isNaN(valorPago) || valorCompra !== parseFloat(valorCompraInput.value) || valorPago !== parseFloat(valorPagoInput.value)) {
      alert('Por favor, preencha todos os campos.');
      return;
    }

    if (valorPago < valorCompra) {
      alert('Valor pago deve ser superior ao valor da compra.');
      return;
    }

    let troco = valorPago - valorCompra;
    const notasCem = Math.floor(troco / 100);
    troco %= 100;
    const notasDez = Math.floor(troco / 10);
    troco %= 10;
    const notasUm = Math.floor(troco);

    // Construindo o modal
    const modalContent = `
      <p>Valor da compra: R$ ${valorCompra.toFixed(2)}</p>
      <p>Valor do troco: R$ ${(valorPago - valorCompra).toFixed(2)}</p>
      <p>Notas de R$100: ${notasCem}</p>
      <p>Notas de R$10: ${notasDez}</p>
      <p>Notas de R$1: ${notasUm}</p>
    `;

    document.getElementById('modalBody').innerHTML = modalContent;

    $('#resultadoModal').modal('show');
  });

  valorCompraInput.addEventListener('input', () => {
    valorCompraInput.value = valorCompraInput.value.replace(/[^\d]/g, '');
  });

  valorPagoInput.addEventListener('input', () => {
    valorPagoInput.value = valorPagoInput.value.replace(/[^\d]/g, '');
    
  });
});