document.addEventListener("DOMContentLoaded", function() {
  const form = document.querySelector('form');
document.getElementById('consultarCeps');
  const modalBody = document.getElementById('modalBody');
  const resultadoModal = new bootstrap.Modal(document.getElementById('resultadoModal'));
const menuButton = document.getElementById('menu');

menuButton.addEventListener('click', () => {
  window.location.href = 'https://desafioabraselmain.gabi2255.repl.co/';
});
  form.addEventListener('submit', function(event) {
    event.preventDefault();
    const ceps = [];
    const cepInputs = document.querySelectorAll('input[type="text"]');
    
    // Validando e armazenando os CEPs no array
    cepInputs.forEach(input => {
      if (input.value.trim() !== '') {
        ceps.push(input.value.trim());
      }
    });

    if (ceps.length === 0) {
      alert('Por favor, insira pelo menos um CEP.');
      return;
    }

    consultarCEPs(ceps);
  });

  async function consultarCEPs(ceps) {
    modalBody.innerHTML = ''; 

    for (let i = 0; i < ceps.length; i++) {
      const response = await fetch(`https://viacep.com.br/ws/${ceps[i]}/json/`);
      const data = await response.json();

      // Exibindo as informações no modal
      if (!data.erro) {
        const endereco = `
          <strong>CEP:</strong> ${data.cep}<br>
          <strong>Logradouro:</strong> ${data.logradouro}<br>
          <strong>Bairro:</strong> ${data.bairro}<br>
          <strong>Cidade:</strong> ${data.localidade}<br>
          <strong>Estado:</strong> ${data.uf}<br>
        `;
        modalBody.innerHTML += `<p><strong>CEP ${i + 1}:</strong></p>${endereco}<br>`;
      } else {
        modalBody.innerHTML += `<p>Não foi possível encontrar informações para o CEP ${ceps[i]}.</p><br>`;
      }
    }

    // Abrindo o modal com as informações obtidas
    resultadoModal.show();
  }

  // Limpar o modal ao fechar
  resultadoModal._element.addEventListener('hidden.bs.modal', function () {
    modalBody.innerHTML = '';
  });
});