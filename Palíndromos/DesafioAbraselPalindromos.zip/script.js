const menuButton = document.querySelector('.overlay-panel.overlay-right #menu');

// redirecionamento para o menu do desafio
menuButton.addEventListener('click', () => {
  window.location.href = 'https://desafioabraselmain.gabi2255.repl.co/';
});

// verificações palindromos
document.getElementById('verPalindromos').addEventListener('click', function() {
  const numeroInicial = parseInt(document.getElementById('numeroInicial').value);
  const numeroFinal = parseInt(document.getElementById('numeroFinal').value);

  function isPalindromo(num) {
    const reversed = parseInt(num.toString().split('').reverse().join(''));
    return num === reversed;
  }

  function findPalindromos(inicio, fim) {
    const palindromos = [];
    for (let i = inicio; i <= fim; i++) {
      if (isPalindromo(i)) {
        palindromos.push(i);
      }
    }
    return palindromos;
  }

  const palindromosEncontrados = findPalindromos(numeroInicial, numeroFinal);
  const palindromosElement = document.getElementById('palindromosEncontrados');

  if (palindromosEncontrados.length > 0) {
    palindromosElement.textContent = 'Números palíndromos encontrados :\n\n' + palindromosEncontrados.join(', ');
  } else {
    palindromosElement.textContent = 'Nenhum número palíndromo encontrado no intervalo.';
  }

  // Exibição do modal
  $('#resultadoModal').modal('show');
});